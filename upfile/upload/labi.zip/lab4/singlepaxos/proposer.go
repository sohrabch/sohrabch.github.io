// +build !solution

package singlepaxos


import (
	"time"

	detector "../../lab3/detector"
)

// Proposer represents a proposer as defined by the single-decree Paxos
// algorithm.
type Proposer struct {
	crnd          Round
	ClientValue   Value
	id            int
	nrOfNodes     int
	ld            detector.LeaderDetector // instance of leader-detector
	delayTime     time.Duration           // delay time for the time-out
	tickerTime    *time.Ticker            // the ticker timeout
	currentLeader int
	quorum        int
	promiseList   map[int]Promise //received promises list from acceptors
	stop          chan bool
	syncProposer  bool
	LdToChan      <-chan int
	prepareOut    chan<- Prepare // Channel for sending Prepare message
	PrmIn         chan Promise   // Channel for receiving Promise message
	acceptOut     chan<- Accept  // Channel for sending Accept message
	ClientValChan chan Value     // Channel for receiving Client value
	clientValue   Value
}

// NewProposer returns a new single-decree Paxos proposer.
// It takes the following arguments:
//
// id: The id of the node running this instance of a Paxos proposer.
//
// nrOfNodes: The total number of Paxos nodes.
//
// ld: A leader detector implementing the detector.LeaderDetector interface.
//
// prepareOut: A send only channel used to send prepares to other nodes.
//
// The proposer's internal crnd field should initially be set to the value of
// its id.
func NewProposer(id int, nrOfNodes int, ld detector.LeaderDetector, prepareOut chan<- Prepare, acceptOut chan<- Accept) *Proposer {
	return &Proposer{
		crnd:          Round(id),
		ld:            ld,
		delayTime:     2 * time.Second,
		tickerTime:    time.NewTicker(2 * time.Second),
		nrOfNodes:     nrOfNodes,
		id:            id,
		currentLeader: id,
		quorum:        (nrOfNodes / 2) + 1,
		promiseList:   make(map[int]Promise, nrOfNodes),
		stop:          make(chan bool),
		LdToChan:      make(chan int),
		prepareOut:    prepareOut,
		PrmIn:         make(chan Promise),
		acceptOut:     acceptOut,
		ClientValChan: make(chan Value),
	}
}

// Start starts p's main run loop as a separate goroutine. The main run loop
// handles incoming promise messages and leader detector trust messages.
func (p *Proposer) Start() {
	go func() {
		p.LdToChan = p.ld.Subscribe()
		for {
			select {
			case <-p.tickerTime.C:
				counter := 0
				moreThanHalf := false
				for _, prmMsg := range p.promiseList {
					if prmMsg.Rnd == p.crnd {
						counter++
					}
				}
				if counter >= p.quorum {
					moreThanHalf = true
				}
				if !moreThanHalf && !p.syncProposer {
					if len(string(p.clientValue)) > 0 {
						p.increaseCrnd()
						prepare := Prepare{p.id, p.crnd}
						p.prepareOut <- prepare
						p.tickerTime = time.NewTicker(p.delayTime)
					}
				}

			case prmMsg := <-p.PrmIn:
				accept, out := p.handlePromise(prmMsg)
				if out && !p.syncProposer {
					p.acceptOut <- accept
					p.syncProposer = true
				}

			case clientValue := <-p.ClientValChan:
				if p.currentLeader == p.id {
					p.clientValue = clientValue
					if len(string(p.clientValue)) > 0 {
						p.increaseCrnd()
						prepare := Prepare{p.id, p.crnd}
						p.prepareOut <- prepare
						p.tickerTime = time.NewTicker(p.delayTime)
					}
					p.syncProposer = false
				}

			case newLeader := <-p.LdToChan:
				p.currentLeader = newLeader

			case <-p.stop:
				return
			}
		}
	}()
}

// Stop stops p's main run loop.
func (p *Proposer) Stop() {
	p.stop <- true
}

// DeliverPromise delivers promise prm to proposer p.
func (p *Proposer) DeliverPromise(prm Promise) {
	p.PrmIn <- prm
}

// DeliverClientValue delivers client value val from client to proposer p.
func (p *Proposer) DeliverClientValue(val Value) {
	p.ClientValChan <- val
}

// Internal: handlePromise processes promise prm according to the single-decree
// Paxos algorithm. If handling the promise results in proposer p emitting a
// corresponding accept, then output will be true and acc contain the promise.
// If handlePromise returns false as output, then acc will be a zero-valued
// struct.
func (p *Proposer) handlePromise(prm Promise) (acc Accept, output bool) {
	higherRndVal := false
	counter := 0
	moreThanHalf := false

	if prm.Rnd == p.crnd {
		prevPrmVal, exist := p.promiseList[prm.From]
		if !exist { // gets new promise from a new acceptor
			p.promiseList[prm.From] = prm
			// Checking whether another clientVal is chosen
			if prm.Vrnd != NoRound && prm.Vval != ZeroValue {
				// Checking whether value with higher round exists
				for _, promise := range p.promiseList {
					if promise.Vrnd > prm.Vrnd {
						higherRndVal = true
					}
				}
				if !higherRndVal {
					p.clientValue = prm.Vval
				}
			}
		} else { // gets new promise from an already existing acceptor
			if prevPrmVal.Rnd < prm.Rnd {
				p.promiseList[prm.From] = prm
				if prevPrmVal.Vrnd < prm.Vrnd {
					p.clientValue = prm.Vval
				}
			} else if prevPrmVal.Vrnd < prm.Vrnd {
				p.clientValue = prm.Vval
			}
		}
		// Send Accept if promise received from majority of the acceptors
		for _, prmMsg := range p.promiseList {
			if prmMsg.Rnd == p.crnd {
				counter++
			}
		}
		if counter >= p.quorum {
			moreThanHalf = true
		}
		if moreThanHalf {
			accept := Accept{p.id, p.crnd, p.clientValue}
			return accept, true
		}
	}
	return Accept{}, false
}

// Internal: increasecrnd increases proposer p's crnd field by the total number
// of Paxos nodes.
func (p *Proposer) increaseCrnd() {
	p.crnd = p.crnd + Round(p.nrOfNodes)
}
