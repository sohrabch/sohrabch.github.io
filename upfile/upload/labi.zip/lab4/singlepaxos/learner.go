// +build !solution

package singlepaxos

// Learner represents a learner as defined by the single-decree Paxos
// algorithm.
type Learner struct {
	clientValue    Value        // Chosen client value
	learnMsgsIn    chan Learn   // Channel to recv Learn message
	clientValueOut chan<- Value // Channel to send chosen value
	stop           chan bool    // Channel for signalling a stop request to the start run loop
	nrOfNodes      int
	id             int
	quorum         int
	IDToLearn      map[int]Learn // Map if nodeID and Learn message
}

// NewLearner returns a new single-decree Paxos learner. It takes the
// following arguments:
//
// id: The id of the node running this instance of a Paxos learner.
//
// nrOfNodes: The total number of Paxos nodes.
//
// valueOut: A send only channel used to send values that has been IDToLearn,
// i.e. decided by the Paxos nodes.
func NewLearner(id int, nrOfNodes int, valueOut chan<- Value) *Learner {
	return &Learner{

		clientValue:    ZeroValue,
		learnMsgsIn:    make(chan Learn),
		clientValueOut: valueOut,
		stop:           make(chan bool),
		nrOfNodes:      nrOfNodes,
		id:             id,
		quorum:         (nrOfNodes / 2) + 1,
		IDToLearn:      make(map[int]Learn, nrOfNodes),
	}
}

// Start starts l's main run loop as a separate goroutine. The main run loop
// handles incoming learn messages.
func (l *Learner) Start() {
	go func() {
		for {
			select {
			case <-l.stop:
				return
			case learner_msg := <-l.learnMsgsIn:
				handle_value, out := l.handleLearn(learner_msg)
				if out {
					l.clientValueOut <- handle_value
					l.IDToLearn = map[int]Learn{}
				}
			}
		}
	}()
}

// Stop stops l's main run loop.
func (l *Learner) Stop() {
	l.stop <- true
}

// DeliverLearn delivers learn lrn to learner l.
func (l *Learner) DeliverLearn(lrn Learn) {
	l.learnMsgsIn <- lrn
}

// Internal: handleLearn processes learn lrn according to the single-decree
// Paxos algorithm. If handling the learn results in learner l emitting a
// corresponding decided value, then output will be true and val contain the
// decided value. If handleLearn returns false as output, then val will have
// its zero value.
func (l *Learner) handleLearn(learn Learn) (val Value, output bool) {
	prev_val, ok := l.IDToLearn[learn.From]
	if !ok || learn.Rnd > prev_val.Rnd {
		l.IDToLearn[learn.From] = learn
	}
	count := make(map[int]int)
	value := make(map[int]Value)

	for _, learner := range l.IDToLearn {
		count[int(learner.Rnd)]++
		value[int(learner.Rnd)] = learner.Val
	}
	for round, val := range value {
		if count[int(round)] >= l.quorum {
			return val, true
		}
	}
	return ZeroValue, false
}
