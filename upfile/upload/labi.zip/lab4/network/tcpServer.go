package network

import (
	"encoding/gob"
	"log"
	"net"
	"strings"
	"time"

	dtr "../../lab3/detector"

	paxos "../../lab4/singlepaxos"
)

// Process outgoing messages
func (s *ServerHandler) Handle_Outgoing_Msgs() {
	hbt_fd := dtr.Heartbeat{
		To:      -1,
		From:    -1,
		Request: false,
	}
	var client_data HeartbeatProto

	prepareIn := paxos.Prepare{
		From: int(paxos.NoRound),
		Crnd: paxos.NoRound,
	}
	Recv_Promise_Msg_Chan := paxos.Promise{
		To:   int(paxos.NoRound),
		From: int(paxos.NoRound),
		Rnd:  paxos.NoRound,
		Vrnd: paxos.NoRound,
		Vval: paxos.ZeroValue,
	}
	acceptIn := paxos.Accept{
		From: int(paxos.NoRound),
		Rnd:  paxos.NoRound,
		Val:  paxos.ZeroValue,
	}
	learnMsgsIn := paxos.Learn{
		From: int(paxos.NoRound),
		Rnd:  paxos.NoRound,
		Val:  paxos.ZeroValue,
	}
	var valOut paxos.Value

	for {
		select {
		case hbt_fd = <-s.Receive_Outgoing_Hbt_Msgs:
			if hbt_fd.Request {
				if hbt_fd.From == hbt_fd.To {
					//send hbt request to local node
					hbt_reply := dtr.Heartbeat{
						From:    hbt_fd.From,
						To:      hbt_fd.To,
						Request: false,
					}
					//send hbt reply to local node
					s.Fd.DeliverHeartbeat(hbt_reply)
				} else {

					// send hbt request to peer node
					client_data = HeartbeatProto{
						Heartbeat_Type: "REQ_HB",
						From_Id:        hbt_fd.From,
						To_Id:          hbt_fd.To,
					}

					s.Outgoing_server_Message <- ServerClientHandler{
						Client_Hbt_Data:   client_data,
						Client_Connection: nil,
					}
				}
			} else {
				// send hbt response to peer node
				client_data = HeartbeatProto{
					Heartbeat_Type: "RES_HB",
					From_Id:        hbt_fd.From,
					To_Id:          hbt_fd.To,
				}
				if s.Client_Ids_With_Connection_Handler[hbt_fd.To] != nil {
					read_client_data := gob.NewEncoder(s.Client_Ids_With_Connection_Handler[hbt_fd.To])
					err := read_client_data.Encode(&client_data)
					if err != nil {
						s.Client_Ids_With_Connection_Handler[hbt_fd.To].Close()
						s.Client_Ids_With_Connection_Handler[hbt_fd.To] = nil
					}
				}
			}

		case valOut = <-s.Recv_Chosen_Value_Chan:

			if !s.check_duplicate_chosen_value {
				s.Send_Chosen_Val_To_Ext_Client(string(valOut))
				s.check_duplicate_chosen_value = true
			}

		case acceptIn = <-s.acceptIn:

			// send accept message to the acceptor of this node

			s.Acceptor.DeliverAccept(acceptIn)
			client_data = HeartbeatProto{
				Heartbeat_Type: "ACCEPT",
				From_Id:        acceptIn.From,
				Rnd:            int(acceptIn.Rnd),
				Val:            string(acceptIn.Val),
			}
			s.Outgoing_server_Message <- ServerClientHandler{
				Client_Hbt_Data:   client_data,
				Client_Connection: nil,
			}

		case learnMsgsIn = <-s.learnMsgsIn:

			//send learn message from acceptor to the learner of this node

			s.Learner.DeliverLearn(learnMsgsIn)
			client_data = HeartbeatProto{
				Heartbeat_Type: "LEARN",
				From_Id:        learnMsgsIn.From,
				Rnd:            int(learnMsgsIn.Rnd),
				Val:            string(learnMsgsIn.Val),
			}

			s.Outgoing_server_Message <- ServerClientHandler{
				Client_Hbt_Data:   client_data,
				Client_Connection: nil,
			}

		case Recv_Promise_Msg_Chan = <-s.Recv_Promise_Msg_Chan:

			//send promise message to the proposer of this node

			if s.id == Recv_Promise_Msg_Chan.To {
				s.Proposer.DeliverPromise(Recv_Promise_Msg_Chan)
			} else {
				client_data = HeartbeatProto{
					Heartbeat_Type: "PROMISE",
					From_Id:        Recv_Promise_Msg_Chan.From,
					To_Id:          Recv_Promise_Msg_Chan.To,
					Rnd:            int(Recv_Promise_Msg_Chan.Rnd),
					Vrnd:           int(Recv_Promise_Msg_Chan.Vrnd),
					Val:            string(Recv_Promise_Msg_Chan.Vval),
				}
				s.Outgoing_server_Message <- ServerClientHandler{
					Client_Hbt_Data:   client_data,
					Client_Connection: nil,
				}
			}

		case prepareIn = <-s.prepareIn:

			//send prepare message to the acceptor of this node

			s.Acceptor.DeliverPrepare(prepareIn)
			client_data = HeartbeatProto{
				Heartbeat_Type: "PREPARE",
				From_Id:        prepareIn.From,
				Rnd:            int(prepareIn.Crnd),
			}
			s.Outgoing_server_Message <- ServerClientHandler{
				Client_Hbt_Data:   client_data,
				Client_Connection: nil,
			}

		}
	}
}

// process incoming messages from other nodes
func (s *ServerHandler) Handle_Incoming_Peer_Msg(new_msg_from_client ServerClientHandler) {
	switch new_msg_from_client.Client_Hbt_Data.Heartbeat_Type {

	case "RES_HB":
		hbt_reply := dtr.Heartbeat{
			From:    new_msg_from_client.Client_Hbt_Data.From_Id,
			To:      new_msg_from_client.Client_Hbt_Data.To_Id,
			Request: false,
		}
		s.Fd.DeliverHeartbeat(hbt_reply)

	case "REQ_HB":
		hbt_request := dtr.Heartbeat{
			From:    new_msg_from_client.Client_Hbt_Data.From_Id,
			To:      new_msg_from_client.Client_Hbt_Data.To_Id,
			Request: true,
		}

		s.Fd.DeliverHeartbeat(hbt_request)

	case "EXTCLVALUE":
		//fmt.Printf("external clien")
		s.Proposer.DeliverClientValue(paxos.Value(new_msg_from_client.Client_Hbt_Data.Val))
		s.check_duplicate_chosen_value = false

	case "ACCEPT":
		acceptIn := paxos.Accept{
			From: new_msg_from_client.Client_Hbt_Data.From_Id,
			Rnd:  paxos.Round(new_msg_from_client.Client_Hbt_Data.Rnd),
			Val:  paxos.Value(new_msg_from_client.Client_Hbt_Data.Val),
		}
		s.Acceptor.DeliverAccept(acceptIn)
	case "PROMISE":
		promiseIn := paxos.Promise{

			From: new_msg_from_client.Client_Hbt_Data.From_Id,
			To:   new_msg_from_client.Client_Hbt_Data.To_Id,
			Rnd:  paxos.Round(new_msg_from_client.Client_Hbt_Data.Rnd),
			Vrnd: paxos.Round(new_msg_from_client.Client_Hbt_Data.Vrnd),
			Vval: paxos.Value(new_msg_from_client.Client_Hbt_Data.Val),
		}
		s.Proposer.DeliverPromise(promiseIn)
	case "LEARN":
		learnIn := paxos.Learn{
			From: new_msg_from_client.Client_Hbt_Data.From_Id,
			Rnd:  paxos.Round(new_msg_from_client.Client_Hbt_Data.Rnd),
			Val:  paxos.Value(new_msg_from_client.Client_Hbt_Data.Val),
		}
		s.Learner.DeliverLearn(learnIn)

	case "PREPARE":

		prepareIn := paxos.Prepare{
			From: new_msg_from_client.Client_Hbt_Data.From_Id,
			Crnd: paxos.Round(new_msg_from_client.Client_Hbt_Data.Rnd),
		}

		s.Acceptor.DeliverPrepare(prepareIn)

	}
}

// precess incoming message from other peer clients
func (s *ServerHandler) Receive_Msg_from_Peer_Client(peer_ip string, peer_conn net.Conn) {
	for {
		var client_data HeartbeatProto
		read_client_data := gob.NewDecoder(peer_conn)
		err := read_client_data.Decode(&client_data)
		if err != nil {
			peer_conn.Close()
			s.Client_Ids_With_Connection_Handler[IDResolver[peer_ip]] = nil
			return
		}

		if len(client_data.Heartbeat_Type) > 0 {
			s.Incoming_server_Message <- ServerClientHandler{Client_Hbt_Data: client_data, Client_Connection: nil}
		}
	}
}

// Receive message from external client
func (s *ServerHandler) Receive_Msg_from_Ext_Client(peer_ip string, peer_conn net.Conn) {
	for {
		var client_data HeartbeatProto
		gob_decoder := gob.NewDecoder(peer_conn)
		err := gob_decoder.Decode(&client_data)
		if err != nil {
			peer_conn.Close()
			s.External_Client_Ips[peer_ip] = nil
			return
		}
		if len(client_data.Heartbeat_Type) > 0 {
			s.Incoming_server_Message <- ServerClientHandler{Client_Hbt_Data: client_data, Client_Connection: nil}
		}
	}
}

// process new client connection
func (s *ServerHandler) Handle_New_Client_Connection() {
	go s.Handle_Outgoing_Msgs()

	for {
		Client_Connection, err := s.ServerListener.Accept()
		if err != nil {
			Client_Connection = nil
		} else {
			client_ip := strings.Split(Client_Connection.RemoteAddr().String(), ":")

			if _, ok := IDResolver[client_ip[0]]; !ok && s.External_Client_Ips[client_ip[0]] == nil {
				s.External_Client_Ips[client_ip[0]] = Client_Connection

				go s.Receive_Msg_from_Ext_Client(client_ip[0], Client_Connection)
			} else {
				s.Client_Ids_With_Connection_Handler[IDResolver[client_ip[0]]] = Client_Connection
				go s.Receive_Msg_from_Peer_Client(client_ip[0], Client_Connection)
			}

		}
	}
}

// Notify the chosen value to the external client
func (s *ServerHandler) Send_Chosen_Val_To_Ext_Client(chVal string) {
	for ip_addr, conn := range s.External_Client_Ips {
		if conn != nil {
			data := HeartbeatProto{Heartbeat_Type: "CHVALUE", From_Id: s.id, Val: chVal}
			gob_encoder := gob.NewEncoder(conn)
			err := gob_encoder.Encode(data)
			if err != nil {
				conn.Close()
				s.External_Client_Ips[ip_addr] = nil
			}
		}
	}
}

// for application server stop
func (s *ServerHandler) Stop() {
	s.stop <- true
}

// for application server start
func (s *ServerHandler) Start() {
	go s.Handle_New_Client_Connection()
	var new_msg_from_client ServerClientHandler

	go func() {
		for {
			select {
			case new_msg_from_client = <-s.Incoming_server_Message:
				s.Handle_Incoming_Peer_Msg(new_msg_from_client)
			case <-s.stop:
				return
			}
		}
	}()
}

//intialising server part
func ServerInitialization(ld *dtr.MonLeaderDetector,
	data_in chan ServerClientHandler,
	data_out chan ServerClientHandler,
	proposer *paxos.Proposer,
	acceptor *paxos.Acceptor,
	learner *paxos.Learner,
	prpOut chan paxos.Prepare,
	accOut chan paxos.Accept,
	promOut chan paxos.Promise,
	lrnValOut chan paxos.Learn,
	chValOut chan paxos.Value,
) (*ServerHandler, error) {
	log.SetFlags(log.Ldate | log.Ltime)

	IPAddress = IPFinder()

	Receive_Outgoing_Hbt_Msgs := make(chan dtr.Heartbeat, 16)
	fd := dtr.NewEvtFailureDetector(IDResolver[IPAddress], NodeIDs, ld, time.Second, Receive_Outgoing_Hbt_Msgs)

	resolvedIP, err1 := net.ResolveTCPAddr("tcp", IPAddress+":"+portNum)
	if err1 != nil {
		return nil, err1
	}

	ServerListener, err2 := net.ListenTCP("tcp", resolvedIP)
	if err2 != nil {
		return nil, err2
	}

	ServerHandlerData := ServerHandler{
		ServerListener:                     ServerListener,
		Fd:                                 fd,
		Receive_Outgoing_Hbt_Msgs:          Receive_Outgoing_Hbt_Msgs,
		Incoming_server_Message:            data_in,
		Outgoing_server_Message:            data_out,
		Client_Ids_With_Connection_Handler: make(map[int]net.Conn),
		stop:                               make(chan bool),

		id:                     IDResolver[IPAddress],
		External_Client_Ips:    make(map[string]net.Conn),
		Proposer:               proposer,
		Acceptor:               acceptor,
		Learner:                learner,
		prepareIn:  prpOut,
		acceptIn:   accOut,
		Recv_Promise_Msg_Chan:  promOut,
		learnMsgsIn:    lrnValOut,
		Recv_Chosen_Value_Chan: chValOut,
	}

	return &ServerHandlerData, nil
}
