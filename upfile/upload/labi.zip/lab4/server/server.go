package app

import (
	"log"

	net "../../lab4/network"
)

type AppHandler struct {
	ld   <-chan int
	stop chan bool
}

//start the app
func (a *AppHandler) Start() {
	log.SetFlags(log.Ldate | log.Ltime)
	var newLeader int
	var ipAddress string = ""

	go func() {
		for {
			select {
			case newLeader = <-a.ld: // Listen for leader change
				for ip, id := range net.IDResolver {
					if id == newLeader {
						ipAddress = ip
						break
					}
				}
				log.Printf("Leader changed to node id %d with ip address %s", newLeader, ipAddress)
			case <-a.stop:
				return
			}
		}
	}()
}

//stop the app
func (a *AppHandler) Stop() {
	a.stop <- true
}

// Initialise the Application
func AppInitialization(ld <-chan int) (*AppHandler, error) {
	AppHandlerData := AppHandler{
		ld:   ld,
		stop: make(chan bool),
	}

	return &AppHandlerData, nil
}
