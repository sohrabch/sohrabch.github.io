// +build !solution

package multipaxos

import "sort"
// Acceptor represents an acceptor as defined by the Multi-Paxos algorithm.
type Acceptor struct {
	//TODO(student): Task 2 and 3 - algorithm and distributed implementation
	// Add needed fields

        acceptedRnd Round // Last round until now
        lastVoteVal   Value // Previous voted value
	lastVoteRnd   Round // Previous voted round
	slotID   SlotID // Slot id
	lastSlotID  SlotID // previous Slot id
	slots map[SlotID]PromiseSlot 

	id         int
        stop       chan bool      // Channel for signalling a stop request to the start run loop
        sendLrnMsg   chan<- Learn   // Channel to send Learn message
        receiveAccMsg   chan Accept    // Channel to recv Accept message
        sendPrmMsg chan<- Promise // Channel to send Promise message
        receivePrpMsg  chan Prepare   // Channel to recv Prepare message



}

// NewAcceptor returns a new single-decree Paxos acceptor.
// It takes the following arguments:
//
// id: The id of the node running this instance of a Paxos acceptor.
//
// sendPrmMsg: A send only channel used to send promises to other nodes.
//
// sendLrnMsg: A send only channel used to send learns to other nodes.
func NewAcceptor(id int, sendPrmMsg chan<- Promise, sendLrnMsg chan<- Learn) *Acceptor {
	//TODO(student): Task 2 and 3 - algorithm and distributed implementation
	return &Acceptor{
		

                acceptedRnd:     NoRound,
                lastVoteRnd:       NoRound,
		slots : make(map[SlotID]PromiseSlot),
		id:         id,
                stop:       make(chan bool),
                sendLrnMsg:   sendLrnMsg,
                receiveAccMsg:   make(chan Accept),
                sendPrmMsg: sendPrmMsg,
                receivePrpMsg:  make(chan Prepare),



		}
}

// Start starts a's main run loop as a separate goroutine. The main run loop
// handles incoming prepare and accept messages.
func (a *Acceptor) Start() {
	go func() {
		for {
			//TODO(student): Task 3 - distributed implementation

			select {
 			case <-a.stop:
                                return

		   	case accept_msg := <-a.receiveAccMsg:
                                learner_msg, out := a.handleAccept(accept_msg)
                                if out {
                                        a.sendLrnMsg <- learner_msg
                                }
                        case prpMsg := <-a.receivePrpMsg:
                                promise_msg, out := a.handlePrepare(prpMsg)
                                if out {
                                        a.sendPrmMsg <- promise_msg
                                }
                       
                        }

		}
	}()
}

// Stop stops a's main run loop.
func (a *Acceptor) Stop() {
	
	 a.stop <- true
}


func (a *Acceptor) DeliverPrepare(prpMsg Prepare) {
	//TODO(student): Task 3 - distributed implementation
	a.receivePrpMsg <- prpMsg
}

// DeliverAccept delivers accept acc to acceptor a.
func (a *Acceptor) DeliverAccept(acc Accept) {
	//TODO(student): Task 3 - distributed implementation
	a.receiveAccMsg <- acc
}

// Internal: handlePrepare processes prepare prp according to the Multi-Paxos
// algorithm. If handling the prepare results in acceptor a emitting a
// corresponding promise, then output will be true and prm contain the promise.
// If handlePrepare returns false as output, then prm will be a zero-valued
// struct.
func (a *Acceptor) handlePrepare(prpMsg Prepare) (prm Promise, output bool) {
	




	 if prpMsg.Crnd > a.acceptedRnd {
                a.acceptedRnd = prpMsg.Crnd
                a.slotID = prpMsg.Slot





		accSlots := []PromiseSlot{}
                for slotID, promised_slot := range a.slots {
                        if slotID >= prpMsg.Slot {
				
                              accSlots = append(accSlots, promised_slot )
                        }
                }

                sort.Sort(slot_data(accSlots)) 

		
                promise := Promise{To: prpMsg.From, From: a.id, Rnd: a.acceptedRnd}

                if len(accSlots) > 0 {
                        promise.Slots = accSlots
                }


                return promise, true
        } else {
                return Promise{}, false
        }

}

// Internal: handleAccept processes accept acc according to the Multi-Paxos
// algorithm. If handling the accept results in acceptor a emitting a
// corresponding learn, then output will be true and lrn contain the learn.  If
// handleAccept returns false as output, then lrn will be a zero-valued struct.
func (a *Acceptor) handleAccept(acc Accept) (lrn Learn, output bool) {
	//TODO(student): Task 2 - algorithm implementation
	//return Learn{From: -1, Rnd: -2, Val: "FooBar"}, true
	if acc.Rnd >= a.acceptedRnd { // New round, or same round (incase of duplicate accept message)
		a.acceptedRnd = acc.Rnd                
                a.lastVoteVal = acc.Val
		a.lastVoteRnd = acc.Rnd
		a.slotID = acc.Slot
		a.lastSlotID = acc.Slot
		
		accSlot := PromiseSlot{ID: acc.Slot, Vrnd: a.lastVoteRnd, Vval: a.lastVoteVal}
			
		lastSlt, errcheck := a.slots[acc.Slot]

                if (errcheck && lastSlt.Vrnd < acc.Rnd) || !errcheck { 
		
                        a.slots[acc.Slot] = accSlot
                }


	

                learn := Learn{
				a.id,
				a.slotID,
				a.lastVoteRnd,
				a.lastVoteVal,
			}

                return learn, true
        } else {
                return Learn{}, false
        }


}







// Sort the Promise Slot by ID
type slot_data []PromiseSlot

// This function is used by sort interface to find the length of slice
func (slice slot_data) Len() int {
        return len(slice)
}

// This function is used by sort interface to find minimum ID
func (slice slot_data) Less(i, j int) bool {
	return slice[i].ID < slice[j].ID
}

// This function is used by sort interface to swap entries
func (slice slot_data) Swap(i, j int) {
        slice[i], slice[j] = slice[j], slice[i]
}


