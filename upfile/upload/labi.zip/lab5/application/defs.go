package app

import dtr "../../lab3/detector"

// Definitions - DO NOT EDIT

var NATIVE_CONN_ADDR string // This node's IP address

// Dictionary of nodeID and it's hostname
var mapOfNodeIDsIPAddr = map[int]string{
	0: "127.0.0.1",
	1: "127.0.0.1",
	2: "127.0.0.1",
}

// App data
type DistributedApp struct {
	leader int                // Leader value
	ld     dtr.LeaderDetector // Interface to leader detector
	stop   chan struct{}      // Channel for signalling a stop request to the start run loop
}
