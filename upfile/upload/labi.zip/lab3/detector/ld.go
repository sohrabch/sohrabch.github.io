// +build !solution

package detector

import (
	"sort"
)

// A MonLeaderDetector represents a Monarchical Eventual Leader Detector as
// described at page 53 in:
// Christian Cachin, Rachid Guerraoui, and Luís Rodrigues: "Introduction to
// Reliable and Secure Distributed Programming" Springer, 2nd edition, 2011.
type MonLeaderDetector struct {
	// TODO(student): Add needed fields
	nodeIDs     []int        // node ids for every node in cluster
	suspected   map[int]bool // map of node ids  considered suspected
	leader      int
	subscribers []chan int
}

// NewMonLeaderDetector returns a new Monarchical Eventual Leader Detector
// given a list of node ids.
func NewMonLeaderDetector(nodeIDs []int) *MonLeaderDetector {
	m := &MonLeaderDetector{}
	m.nodeIDs = nodeIDs
	m.suspected = make(map[int]bool)
	for node := range nodeIDs {
		m.suspected[node] = false
	}
	m.leader = m.Leader()
	return m
}

// Leader returns the current leader. Leader will return UnknownID if all nodes
// are suspected.
func (m *MonLeaderDetector) Leader() int {
	// TODO(student): Implement
	newleader := UnknownID
	sort.Sort(sort.IntSlice(m.nodeIDs))
	for _, node := range m.nodeIDs {
		if !m.suspected[node] && node >= 0 {
			newleader = node
		}
	}
	if newleader != m.leader {
		// if the new leader is different send it to all subs
		for subscriber := range m.subscribers {
			m.subscribers[subscriber] <- newleader

		}
		println("---------------------------")
		println("new leader elected : ", newleader)
		println("---------------------------")
	}
	return newleader
}

// Suspect instructs m to consider the node with matching id as suspected. If
// the suspect indication result in a leader change the leader detector should
// this publish this change its subscribers.
func (m *MonLeaderDetector) Suspect(id int) {
	// TODO(student): Implement
	m.suspected[id] = true
	leaderID := m.Leader()
	m.leader = leaderID
}

// Restore instructs m to consider the node with matching id as restored. If
// the restore indication result in a leader change the leader detector should
// this publish this change its subscribers.
func (m *MonLeaderDetector) Restore(id int) {
	// TODO(student): Implement
	m.suspected[id] = false
	leaderID := m.Leader()
	m.leader = leaderID
}

// Subscribe returns a buffered channel that m on leader change will use to
// publish the id of the highest ranking node. The leader detector will publish
// UnknownID if all nodes become suspected. Subscribe will drop publications to
// slow subscribers. Note: Subscribe returns a unique channel to every
// subscriber; it is not meant to be shared.
func (m *MonLeaderDetector) Subscribe() <-chan int {
	// TODO(student): Implement
	channelsub := make(chan int, 5)
	m.subscribers = append(m.subscribers, channelsub) // stores the channel in a list
	return channelsub                                 // returns a channel
}

// TODO(student): Add other unexported functions or methods if needed.
