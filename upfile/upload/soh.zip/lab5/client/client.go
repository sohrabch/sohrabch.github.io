package client

import (
	"bufio"
	"fmt"
	"log"
	"math"
	"math/rand"
	"os"
	"os/signal"
	"sort"
	"strconv"
	"strings"
	"time"

	"../../lab5/bank"
	"../../lab5/multipaxos"
	"../../lab5/netlayer"
	"../../lab5/util"
)

// Client is a paxos client
type Client struct {
	valueIn     chan multipaxos.Value
	network     *netlayer.Network
	curSequence int

	ClientID  string
	mode      int
	timePassed []time.Time
	rtt       []int
	finished  bool // finished transaction
}

// NewClient assigns the client to the network
func NewClient(network *netlayer.Network, id int, mode int) *Client {
	return &Client{
		valueIn:     make(chan multipaxos.Value),
		network:     network,
		curSequence: 1,
		ClientID:    strconv.Itoa(id),
		mode:        mode,
		finished:    true,
	}
}

// Run runs the client until interruption
func (c *Client) Run() {
	log.Printf("Starting client [%v]\n", c.network.NodeID())

	sig := make(chan os.Signal)
	signal.Notify(sig, os.Interrupt)

	//go c.requestTransaction()
	if c.mode == 0  || c.mode == 1  {
		go c.eventLoopManual()
	} else {
		go c.eventLoopBenchmark()
	}

	<-sig
	fmt.Fprintf(os.Stderr, "\n")
	log.Printf("Received interrupt, shutting down client [%v]\n", c.network.NodeID())
}

// Internal : eventLoop broadcasts input value to the network and displays values voted by the network
func (c *Client) eventLoopManual() {
	if c.network == nil {
		util.Raise("Client is not connected to a network.")
	}

	go c.broadcastTransactions()

	reader := bufio.NewReader(os.Stdin)
	for {
		if c.finished {
			c.finished = false
			fmt.Fprintf(os.Stderr, "-->  Account Number : ")
			val, _ := reader.ReadString('\n')
			accountNr, _ := strconv.Atoi(strings.TrimSuffix(val, "\n"))

			fmt.Fprintf(os.Stderr, "-->  Operation (balance - deposit - withdraw) : ")
			val, _ = reader.ReadString('\n')
			operationIn, _ := strconv.Atoi(strings.TrimSuffix(val, "\n"))

			fmt.Fprintf(os.Stderr, "-->  Amount : ")
			val, _ = reader.ReadString('\n')
			amountIn, _ := strconv.Atoi(strings.TrimSuffix(val, "\n"))

			c.requestTransaction(accountNr, operationIn, amountIn)
		}
	}
}

func (c *Client) eventLoopBenchmark() {
	if c.network == nil {
		util.Raise("Client is not connected to a network.")
	}

	go c.broadcastTransactions()

	for {
		if c.finished && len(c.rtt) < c.mode {
			c.finished = false
			accountNr := rand.Intn(1001)
			operationIn := rand.Intn(3)
			amountIn := rand.Intn(10001)

			c.requestTransaction(accountNr, operationIn, amountIn)
		}
	}
}

func (c *Client) broadcastTransactions() {
	// channel that notifies only this client
	resp := c.network.ListenValueClient()

	for {
		select {
		case val := <-c.valueIn:
			//val.StartTime = time.Now()
			c.network.BroadcastRequestedValue(val)
			//starttime := time.Now()
			log.Printf("Requesting Transaction: %v\n", val)
		case decidedVal := <-resp:
			now := time.Now()
			roundTripTime := now.Sub(c.timePassed[decidedVal.ClientSeq-1])
			log.Printf("Response time %v", int(roundTripTime.Milliseconds()))
			c.rtt = append(c.rtt, int(roundTripTime.Milliseconds()))
			log.Printf("Successful Transaction from node: %v \n transaction details : %v  \n", decidedVal.ClientSeq, decidedVal.TxnRes)
			
			if len(c.rtt) == c.mode {
				statistics(c.rtt)
			}
			c.finished = true
		}
	}
}

// Internal : requestTransaction reads the standard input and forwards newline
// delimited strings to the client main loop
func (c *Client) requestTransaction(accountNr int, operationIn int, amountIn int) {
	transactionIn := bank.Transaction{
		Op:     bank.Operation(operationIn),
		Amount: amountIn,
	}
	val := multipaxos.Value{
		ClientID:  c.ClientID,
		ClientSeq: c.curSequence,
		//Noop:       false,
		AccountNum: accountNr,
		Txn:        transactionIn,
	}
	// increase sequence number
	c.curSequence++
	c.timePassed = append(c.timePassed, time.Now())
	// broadcast value to servers
	c.valueIn <- val
}



//
func statistics(responsetimes []int) {
	

	sort.Ints(responsetimes)
	sum := 0
	for _, time := range responsetimes {
		sum = sum + time
	}
	mean := sum / len(responsetimes)
	minimum := responsetimes[0]
	maximum := responsetimes[len(responsetimes)-1]
	var median int
	if len(responsetimes)%2 != 0 {
		median = responsetimes[(len(responsetimes)+1)/2]
	} else {
		median = (responsetimes[len(responsetimes)/2] + responsetimes[(len(responsetimes)+2)/2]) / 2
	}

	var sumSquaredDifference float64
	for _, time := range responsetimes {
		sumSquaredDifference += math.Pow(float64(time-mean), 2)
	}
	sampleVariance := sumSquaredDifference / float64(len(responsetimes)-1)
	sampleStdev := int(math.Sqrt(sampleVariance))
	fmt.Printf("\n ----------------------\nRoundTrip results from #%v transactions:\nMean: %v millisec\nMin: %v millisec\nMax: %v millisec\nMedian: %v millisec\nSDeviation: %v millisec\n", len(responsetimes), mean, minimum, maximum, median, sampleStdev)
}
