// +build !solution

package singlepaxos

// Acceptor represents an acceptor as defined by the single-decree Paxos
// algorithm.
type Acceptor struct {
	id         int
	learnOut   chan<- Learn   // Channel to send Learn message
	acceptIn   chan Accept    // Channel to recv Accept message
	promiseOut chan<- Promise // Channel to send Promise message
	prepareIn  chan Prepare   // Channel to recv Prepare message
	stop       chan bool
	rnd        Round
	vval       Value
	vrnd       Round
}

// NewAcceptor returns a new single-decree Paxos acceptor.
// It takes the following arguments:
//
// id: The id of the node running this instance of a Paxos acceptor.
//
// promiseOut: A send only channel used to send promises to other nodes.
//
// learnOut: A send only channel used to send learns to other nodes.
func NewAcceptor(id int, promiseOut chan<- Promise, learnOut chan<- Learn) *Acceptor {
	return &Acceptor{
		rnd:        NoRound,
		vval:       ZeroValue,
		vrnd:       NoRound,
		id:         id,
		stop:       make(chan bool),
		learnOut:   learnOut,
		acceptIn:   make(chan Accept),
		promiseOut: promiseOut,
		prepareIn:  make(chan Prepare),
	}
}

// Start starts a's main run loop as a separate goroutine. The main run loop
// handles incoming prepare and accept messages.
func (a *Acceptor) Start() {
	go func() {
		for {
			select {
			case <-a.stop:
				return
			case accept_msg := <-a.acceptIn:
				learner_msg, out := a.handleAccept(accept_msg)
				if out {
					a.learnOut <- learner_msg
				}
			case prepare_msg := <-a.prepareIn:
				promise_msg, out := a.handlePrepare(prepare_msg)
				if out {
					a.promiseOut <- promise_msg
				}
			}
		}
	}()
}

// Stop stops a's main run loop.
func (a *Acceptor) Stop() {
	a.stop <- true
}

// DeliverPrepare delivers prepare prepare_msg to acceptor a.
func (a *Acceptor) DeliverPrepare(prp Prepare) {
	a.prepareIn <- prp
}

// DeliverAccept delivers accept acc to acceptor a.
func (a *Acceptor) DeliverAccept(acc Accept) {
	a.acceptIn <- acc
}

// Internal: handlePrepare processes prepare prepare_msg according to the single-decree
// Paxos algorithm. If handling the prepare results in acceptor a emitting a
// corresponding promise, then output will be true and prm contain the promise.
// If handlePrepare returns false as output, then prm will be a zero-valued
// struct.
func (a *Acceptor) handlePrepare(prp Prepare) (prm Promise, output bool) {
	if prp.Crnd > a.rnd {
		a.rnd = prp.Crnd
		promise := Promise{
			prp.From,
			a.id,
			a.rnd,
			a.vrnd,
			a.vval,
		}
		return promise, true
	} else {
		return Promise{}, false
	}

}

// Internal: handleAccept processes accept acc according to the single-decree
// Paxos algorithm. If handling the accept results in acceptor a emitting a
// corresponding learn, then output will be true and lrn contain the learn.  If
// handleAccept returns false as output, then lrn will be a zero-valued struct.
func (a *Acceptor) handleAccept(acc Accept) (lrn Learn, output bool) {
	if acc.Rnd >= a.rnd {
		a.rnd = acc.Rnd
		a.vval = acc.Val
		a.vrnd = acc.Rnd

		learn := Learn{
			a.id,
			a.vrnd,
			a.vval,
		}
		return learn, true
	} else {
		return Learn{}, false
	}

}
