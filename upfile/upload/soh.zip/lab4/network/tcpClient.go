package network

import (
	"encoding/gob"
	"log"
	"net"
	"time"
)

// process incoming messages from other peer nodes
func (c *ClientHandler) Handle_Incoming_Msgs(peerSrvNodeID int, peer_server string, peer_conn net.Conn) {
	for {
		var data HeartbeatProto
		srvReadGob := gob.NewDecoder(peer_conn)
		err := srvReadGob.Decode(&data)
		if err != nil {
			peer_conn.Close()
			c.Server_Ips_With_Connections[peer_server] = nil
			return
		}

		if len(data.Heartbeat_Type) > 0 {
			c.Incoming_Msg_Channel <- ServerClientHandler{
				Client_Hbt_Data:   data,
				Client_Connection: nil,
			}
		}
	}
}

// process outgoing message from the local node
func (c *ClientHandler) Handle_Outgoing_Msgs(Outgoing_Msg_Channel ServerClientHandler) {
	switch Outgoing_Msg_Channel.Client_Hbt_Data.Heartbeat_Type {

	case "REQ_HB": 
		peer_server := ""
		for ip, id := range IDResolver {
			if id == Outgoing_Msg_Channel.Client_Hbt_Data.To_Id {
				peer_server = ip
				break
			}
		}
		peer_conn := c.Server_Ips_With_Connections[peer_server]
		c.Send_Data_To_Peer_Server(peer_server, peer_conn, Outgoing_Msg_Channel.Client_Hbt_Data)

	case "PREPARE": // Deliver prepare message to peer node acceptor
		for peer_server, peer_conn := range c.Server_Ips_With_Connections {
			Outgoing_Msg_Channel.Client_Hbt_Data.To_Id = IDResolver[peer_server]
			c.Send_Data_To_Peer_Server(peer_server, peer_conn, Outgoing_Msg_Channel.Client_Hbt_Data)
		}

	case "LEARN": // Deliver learn message from acceptor to peer node learner
		for peer_server, peer_conn := range c.Server_Ips_With_Connections {
			Outgoing_Msg_Channel.Client_Hbt_Data.To_Id = IDResolver[peer_server]
			c.Send_Data_To_Peer_Server(peer_server, peer_conn, Outgoing_Msg_Channel.Client_Hbt_Data)
		}

	case "ACCEPT": // Deliver accept message from proposer to peer node acceptor
		for peer_server, peer_conn := range c.Server_Ips_With_Connections {
			Outgoing_Msg_Channel.Client_Hbt_Data.To_Id = IDResolver[peer_server]
			c.Send_Data_To_Peer_Server(peer_server, peer_conn, Outgoing_Msg_Channel.Client_Hbt_Data)
		}

	case "PROMISE": // Deliver promise message from acceptor to peer node proposer
		peer_server := ""
		for ip, id := range IDResolver {
			if id == Outgoing_Msg_Channel.Client_Hbt_Data.To_Id {
				peer_server = ip
				break
			}
		}
		peer_conn := c.Server_Ips_With_Connections[peer_server]
		c.Send_Data_To_Peer_Server(peer_server, peer_conn, Outgoing_Msg_Channel.Client_Hbt_Data)

	}

}

// send data to peer node server
func (c *ClientHandler) Send_Data_To_Peer_Server(peer_server string, peer_conn net.Conn, data HeartbeatProto) {
	if peer_conn != nil {
		srvWriteGob := gob.NewEncoder(peer_conn)
		err := srvWriteGob.Encode(data)
		if err != nil {
			peer_conn.Close()
			c.Server_Ips_With_Connections[peer_server] = nil
		}
	}
}

// connect to available servers
func (c *ClientHandler) Connect_To_Available_Servers() {
	for {
		for server_ip, conn := range c.Server_Ips_With_Connections {
			if conn == nil {
				peer_conn, err := net.Dial("tcp", server_ip+":"+portNum)
				if err != nil {
				} else {
					err = peer_conn.(*net.TCPConn).SetKeepAlive(true)
					if err != nil {
					} else {
						err = peer_conn.(*net.TCPConn).SetKeepAlivePeriod(1800 * time.Second)
						if err != nil {
						}
					}

					c.Server_Ips_With_Connections[server_ip] = peer_conn
					go c.Handle_Incoming_Msgs(IDResolver[server_ip], server_ip, peer_conn)
				}
			}
		}

		time.Sleep(3000 * time.Millisecond)
	}
}

// Stop for application
func (c *ClientHandler) Stop() {
	c.stop <- true
}

// start for application
func (c *ClientHandler) Start() {
	go c.Connect_To_Available_Servers()
	var Outgoing_Msg_Channel ServerClientHandler

	go func() {
		for {
			select {
			case Outgoing_Msg_Channel = <-c.Outgoing_Msg_Channel:
				c.Handle_Outgoing_Msgs(Outgoing_Msg_Channel)
			case <-c.stop:
				return
			}
		}
	}()
}

//client initialisation
func ClientInitialization(data_in chan ServerClientHandler, data_out chan ServerClientHandler) (*ClientHandler, error) {
	log.SetFlags(log.Ldate | log.Ltime)

	IPAddress = IPFinder()

	ClientHandlerData := ClientHandler{
		id:                          IDResolver[IPAddress],
		Incoming_Msg_Channel:        data_in,
		Outgoing_Msg_Channel:        data_out,
		Server_Ips_With_Connections: IPToConn,
		stop:                        make(chan bool),
	}

	return &ClientHandlerData, nil
}
