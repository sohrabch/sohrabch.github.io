package main

import (
	//	"os"
	"bytes"
	"encoding/gob"
	"fmt"
	"log"
	"net"
	"os"
	"strconv"
	"time"

	"./detector"
)

type tcpServer struct {
	con    net.Listener
	rfail  *detector.EvtFailureDetector
	liscon map[int]net.Conn
	lisadd map[int]string
}

func main() {

	//getting passed args
	var arg string
	arg = os.Args[1]
	println("connecting as server number :")
	println(arg)
	println("----------------------------")
	nodeID := NodeIdSetter(arg)
	// setting node IDs and address  ( change for running in different nodes)
	var ID int = nodeID
	NodeiD := []int{0, 1, 2}
	addr := make(map[int]string)
	addr[0] = "localhost:5050"
	addr[1] = "localhost:6060"
	addr[2] = "localhost:7070"
	deadsig := make(chan os.Signal, 1)

	// starting TCP server
	// listening
	server, err := newTCPServer(addr[ID])
	server.lisadd = addr
	if err != nil {
		log.Fatal("Server err: ", err)
	}
	// Dialing for sending
	server.InitialConnection(ID, addr)

	go server.serverTCP()
	sendChannel := make(chan detector.Heartbeat)

	//initializing leader and failure detector

	fail, lead := newDetectors(ID, NodeiD, sendChannel)
	fail.Start()
	server.rfail = fail
	sub := lead.Subscribe()
	go checkChannel(sub)
	go server.transmission(sendChannel, NodeiD)
	<-deadsig
}

//initializer function for LD and FD

func newDetectors(ID int, NodeiD []int, send chan detector.Heartbeat) (*detector.EvtFailureDetector, *detector.MonLeaderDetector) {
	leadDect := detector.NewMonLeaderDetector(NodeiD)
	delay := time.Second
	failDect := detector.NewEvtFailureDetector(ID, NodeiD, leadDect, delay, send)
	return failDect, leadDect
}

func (t *tcpServer) InitialConnection(ID int, addr map[int]string) {
	for key, val := range addr {
		if key != ID {
			conn, err := net.Dial("tcp", val)
			if err != nil {
				fmt.Println("Connection failure: ", err)
			} else {
				t.liscon[key] = conn
			}

		}
	}
}

//printing incoming new leader
func checkChannel(ch <-chan int) {
	for {
		select {
		case i := <-ch:
			fmt.Printf("New leader: %v\n", i)
		}
	}
}

//listening to TCP
func newTCPServer(addr string) (*tcpServer, error) {
	fmt.Println("Creating server " + addr + " ...")
	listener, err := net.Listen("tcp", addr)
	if err != nil {
		log.Fatal("Listen err: ", err)
	}
	liscon := make(map[int]net.Conn)
	server := tcpServer{con: listener, liscon: liscon}
	return &server, err
}

func (t *tcpServer) serverTCP() {
	fmt.Println("Starting server ...")
	list := t.con
	defer list.Close()
	for {

		conn, err := list.Accept()

		if err != nil {
			log.Fatal("Connection err: ", err)
		}
		go t.handleConnection(conn)
	}
}

func (t *tcpServer) handleConnection(conn net.Conn) {
	tmp := make([]byte, 1024)
	conn.Read(tmp)
	tmpbuff := bytes.NewBuffer(tmp)
	tmpstruct := new(detector.Heartbeat)
	gobobj := gob.NewDecoder(tmpbuff)
	gobobj.Decode(tmpstruct)
	if t.rfail != nil {
		fmt.Println("Recieved a HearthBeat from " + strconv.Itoa(tmpstruct.From))
		t.rfail.DeliverHeartbeat(*tmpstruct)
	}

}

func (t *tcpServer) transmission(send chan detector.Heartbeat, NodeID []int) {
	fmt.Println("plan to start transmission")
	for {
		select {
		case beat := <-send:
			if beat.To == beat.From {
				t.rfail.DeliverHeartbeat(beat)
			}
			bin := new(bytes.Buffer)
			gobobj := gob.NewEncoder(bin)
			err := gobobj.Encode(beat)
			if err != nil {
				log.Fatal("Gob Encoding err: ", err)
			}
			if err != nil {
				log.Fatal("Connecting to remote host err:", err)
			}
			_, ok := t.liscon[beat.To]
			if ok == false {

				conn, err := net.Dial("tcp", t.lisadd[beat.To])
				if err != nil {
					fmt.Println(" ----fail to connect to node number :", beat.To)
					continue
				}
				t.liscon[beat.To] = conn
			}
			t.liscon[beat.To].Write(bin.Bytes())
			t.liscon[beat.To].Close()
			delete(t.liscon, beat.To)
		}

	}
}

// string to int convert  for Args
func NodeIdSetter(id string) int {

	i, err := strconv.Atoi(id)

	if err != nil {
		println("wrong node number: ")
		return i
	} else {
		return i
	}

}
