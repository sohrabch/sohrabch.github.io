package main

//main file to start the application
import (
	"log"
	detector "../lab3/detector"
	net "../lab4/network"
	app "../lab4/server"
	paxos "../lab4/singlepaxos"
)

func main() {
	log.SetFlags(log.Ldate | log.Ltime)
	stopApp := make(chan bool)
	dataIn := make(chan net.ServerClientHandler, 5)
	dataOut := make(chan net.ServerClientHandler, 5)
	ld := detector.NewMonLeaderDetector(net.NodeIDs)


	// receiving channels 
	prpMsgIn := make(chan paxos.Prepare, 5)
	accMsgIn := make(chan paxos.Accept, 5)
	prmMsgIn := make(chan paxos.Promise, 5)
	lrnMsgIn := make(chan paxos.Learn, 5)
	chValMsg := make(chan paxos.Value, 1)

	IPAddress := net.IPFinder()
	print("connecting with current IP : " , IPAddress , "\n")

	proposer := paxos.NewProposer( 
		net.IDResolver[IPAddress],
		len(net.NodeIDs),
		ld,
		prpMsgIn,
		accMsgIn,
	)
	acceptor := paxos.NewAcceptor( 
		net.IDResolver[IPAddress],
		prmMsgIn,
		lrnMsgIn,
	)
	learner := paxos.NewLearner( 
		net.IDResolver[IPAddress],
		len(net.NodeIDs),
		chValMsg,
	)

	srv, _ := net.ServerInitialization(ld, dataIn, dataOut, proposer, acceptor, learner,
		prpMsgIn, accMsgIn, prmMsgIn, lrnMsgIn, chValMsg)
	cli, _ := net.ClientInitialization(dataIn, dataOut)
	srv.Start()
	defer srv.Stop()

	cli.Start()
	defer cli.Stop()

	srv.Fd.Start()
	defer srv.Fd.Stop()

	ldrSubscriber := ld.Subscribe()
	app, _ := app.AppInitialization(ldrSubscriber)
	app.Start()
	defer app.Stop()

	srv.Proposer.Start()
	defer srv.Proposer.Stop()

	srv.Acceptor.Start()
	defer srv.Acceptor.Stop()

	srv.Learner.Start()
	defer srv.Learner.Stop()

	<-stopApp
}
