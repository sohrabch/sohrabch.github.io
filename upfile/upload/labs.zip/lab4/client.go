package main

import client "../lab4/client"

func main() {
	stopApp := make(chan bool)      
	clientInstance, _ := client.AppInitialization() 

	clientInstance.Start()      
	defer clientInstance.Stop() 

	<-stopApp 
}
