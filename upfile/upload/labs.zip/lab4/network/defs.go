package network

import (
	"net"
	"os"

	dtr "../../lab3/detector"
	singlePaxos "../../lab4/singlepaxos"
)

var IPAddress string

const portNum = "4300"

var NodeIDs = []int{0, 1, 2}

var IDResolver = map[string]int{
	"152.94.1.114": 0,
	"152.94.1.115": 1,
	"152.94.1.116": 2,
}

type ServerHandler struct {
	ServerListener                     *net.TCPListener
	stop                               chan bool
	Receive_Outgoing_Hbt_Msgs          chan dtr.Heartbeat
	Fd                                 *dtr.EvtFailureDetector
	Incoming_server_Message            chan ServerClientHandler
	Outgoing_server_Message            chan ServerClientHandler
	Client_Ids_With_Connection_Handler map[int]net.Conn
	id                                 int
	External_Client_Ips                map[string]net.Conn
	Learner                            *singlePaxos.Learner
	Acceptor                           *singlePaxos.Acceptor
	Proposer                           *singlePaxos.Proposer
	learnMsgsIn                			chan singlePaxos.Learn
	acceptIn               				chan singlePaxos.Accept
	Recv_Promise_Msg_Chan              chan singlePaxos.Promise
	Recv_Chosen_Value_Chan             chan singlePaxos.Value
	prepareIn              chan singlePaxos.Prepare
	check_duplicate_chosen_value       bool
}

type ClientHandler struct {
	id                          int
	stop                        chan bool
	Incoming_Msg_Channel        chan ServerClientHandler
	Outgoing_Msg_Channel        chan ServerClientHandler
	Server_Ips_With_Connections map[string]net.Conn
}

type HeartbeatProto struct {
	Heartbeat_Type string
	Request        bool
	From_Id        int
	To_Id          int
	Rnd            int    
	Val            string 
	Vrnd           int    
}

type ServerClientHandler struct {
	Client_Hbt_Data   HeartbeatProto
	Client_Connection net.Conn
}

// find the ip address of local system
func IPFinder() string {
	addrs, err := net.InterfaceAddrs()
	if err != nil {
		os.Stderr.WriteString("Oops: " + err.Error() + "\n")
		os.Exit(1)
	}

	for _, a := range addrs {
		if ipnet, ok := a.(*net.IPNet); ok && !ipnet.IP.IsLoopback() {
			if ipnet.IP.To4() != nil {
				return ipnet.IP.String()
			}
		}
	}
	return ""
}

var IPToConn = map[string]net.Conn{
	"152.94.1.114": nil,
	"152.94.1.115": nil,
	"152.94.1.116": nil,
}
