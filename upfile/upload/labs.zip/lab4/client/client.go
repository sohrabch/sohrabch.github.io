package clientApp

import (
	"bufio"
	"encoding/gob"
	"fmt"
	"net"
	"os"
	"time"

	network "../../lab4/network"
)

type clientAppHandler struct {
	SrvIPToConn       map[string]net.Conn 
	Incoming_Msg_Chan chan clientAppMsg   
	User_Value        string              
	Get_User_Value    bool
	stop              chan bool
}

type HeartbeatProto struct {
	Heartbeat_Type string
	Request        bool
	From_Id        int
	To_Id          int
	Rnd            int    
	Val            string 
	Vrnd           int    
}

type clientAppMsg struct {
	Comm_Protocol   HeartbeatProto
	Ext_Client_Conn net.Conn
}

// handle incomign messages
func (c *clientAppHandler) Ext_Client_Handle_Incoming_Msg(peerSrvNodeID int, peer_server string, peer_server_conn net.Conn) {
	for {
		var data HeartbeatProto
		gob_decoder := gob.NewDecoder(peer_server_conn)
		err := gob_decoder.Decode(&data)
		if err != nil {
			peer_server_conn.(*net.TCPConn).Close()
			c.SrvIPToConn[peer_server] = nil
			return
		}

		if len(data.Val) > 0 {
			c.Incoming_Msg_Chan <- clientAppMsg{Comm_Protocol: data, Ext_Client_Conn: nil}
		}
	}
}

// handle outgoing messages
func (c *clientAppHandler) clientMsgOutHndle() {
	scanner := bufio.NewScanner(os.Stdin)

	for {
		
		if c.Get_User_Value {
			fmt.Printf("enter a value to start : ")
			scanner.Scan()
			c.User_Value = scanner.Text()

			fmt.Printf("Value -- %s  -- sent to paxos nodes for decision -- waiting for quorom ! \n", c.User_Value)
			c.clientMsgInHandle()
			c.Get_User_Value = false
		}

		time.Sleep(2000 * time.Millisecond)
		c.Get_User_Value = true
	}
}

// send message to connected servers
func (c *clientAppHandler) clientMsgInHandle() {
	for peer_server, peer_server_conn := range c.SrvIPToConn {
		if peer_server_conn != nil {
			data := HeartbeatProto{Heartbeat_Type: "EXTCLVALUE", Val: c.User_Value}
			gob_encoder := gob.NewEncoder(peer_server_conn)
			err := gob_encoder.Encode(data)
			if err != nil {
				peer_server_conn.Close()
				c.SrvIPToConn[peer_server] = nil
			}
		}
	}
}

// connect to available servers
func (c *clientAppHandler) conectClients() {
	for {
		for peer_server, conn := range c.SrvIPToConn {
			if conn == nil {
				peer_server_conn, err := net.Dial("tcp", peer_server+":4300")
				if err != nil {
				} else {
					err = peer_server_conn.(*net.TCPConn).SetKeepAlive(true)
					if err != nil {
					} else {
						err = peer_server_conn.(*net.TCPConn).SetKeepAlivePeriod(1800 * time.Second)
						if err != nil {
						}
					}

					c.SrvIPToConn[peer_server] = peer_server_conn
					go c.Ext_Client_Handle_Incoming_Msg(network.IDResolver[peer_server], peer_server, peer_server_conn)
				}
			}
		}

		time.Sleep(3000 * time.Millisecond)
	}
}

//stop function
func (c *clientAppHandler) Stop() {
	c.stop <- true
}

//start function
func (c *clientAppHandler) Start() {
	var ipAddress string = ""
	go c.conectClients()
	c.Get_User_Value = true
	go c.clientMsgOutHndle()
	var incoming_msg clientAppMsg

	go func() {
		for {
			select {
			
			case incoming_msg = <-c.Incoming_Msg_Chan:
				for ip, id := range network.IDResolver {
					if id == incoming_msg.Comm_Protocol.From_Id {
						ipAddress = ip
						break
					}
				}
				
				fmt.Printf("\nnode ID # %d with IP Address of %s has selected value --- %s\n ----", incoming_msg.Comm_Protocol.From_Id, ipAddress, incoming_msg.Comm_Protocol.Val)
				println("Quorom Reached ! based on votes")
				c.Get_User_Value = true
			case <-c.stop:
				return
			}
		}
	}()
}

func AppInitialization() (*clientAppHandler, error) {

	clientHandler := clientAppHandler{
		Incoming_Msg_Chan: make(chan clientAppMsg, 1000),
		SrvIPToConn:       network.IPToConn,
		User_Value:        "",
		Get_User_Value:    false,
		stop:              make(chan bool),
	}

	return &clientHandler, nil
}
