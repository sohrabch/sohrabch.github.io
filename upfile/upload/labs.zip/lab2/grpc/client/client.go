// +build !solution

// Leave an empty line above this comment.
package main

func main() {

}
